from django.apps import AppConfig


class ShahkarUserConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "shahkar_user"
